305249641
305613903
*****
comments 
--------
* all broad explanations about the usage or purpose of functions & methods are implemented as documentations, 
    inside the python file.


The python file multi_agent.py contains all the classes and functions that we were asked to solve & complete in this exercise.

We used the same heuristics over the first question and the last one. by creating a linear combination of both "smoothness" and 
"monotony" of the game board, we managed to amp up the final score and highest tile parameters, both while running the game
with the ReflexAgent and the alpha beta pruning technique. at first we used an other heuristic for the first question, 
but after coming up with the solution to the 5th question, we wanted to check it's effectiveness over the ReflexAgent algorithm,
and it proved to work way better, so we decided to use it twice. 



    